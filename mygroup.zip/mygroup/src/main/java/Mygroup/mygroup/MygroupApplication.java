package Mygroup.mygroup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MygroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(MygroupApplication.class, args);
	}

}
